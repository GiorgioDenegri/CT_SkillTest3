<?php

return [

    'base_path'   => 'base/path',

    'app_path'    => 'app/path',
    
    'public_path' => 'public/path'

];